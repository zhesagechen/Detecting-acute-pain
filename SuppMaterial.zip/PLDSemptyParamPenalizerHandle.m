function penalty = PLDSemptyParamPenalizerHandle(params)
%
% function penalty = PLDSemptyParamPenalizerHandle(params)
%

penalty = 0;