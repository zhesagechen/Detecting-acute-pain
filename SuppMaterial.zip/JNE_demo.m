
% NOTE: This is Matlab demo code that replicates the figures in Fig. 3 or
% our paper. One for S1 population, the other for ACC population. 

% Our Matlab demo relies on a package of PLDS variational/Laplace inference written by 
% Dr. Lars Buesing (https://bitbucket.org/mackelab/pop_spike_dyn).
% For simplicity, we only include the essential rountines used in our
% implementation. 



clc;close all


option_S1 = 2

if option_S1 == 1  % S1
    load pain_S1_population.mat; % 150 mW, time 0 is withdrawal
    C = 12;
    xDim = 1;  % latent state dimension 
    NoTrials = 40;
    
else
    load pain_ACC_population.mat; % 150 mW, time 0 is laser onset
    C = 7;
    xDim = 1;  % latent state dimension 
    NoTrials = 16;
end

binsize = 0.05;
TT1 = 5; TT1 = 5;


TT2 = TT1;
edges = [-TT1:binsize:TT2];  % 
seq = struct('T', length(edges), 'y',zeros(C,length(edges)));

%%

  

maxIter = 100;
for trial=  1: NoTrials
    
    binsize = 0.05;
    
    for j=1:NoTrials
        seq = setfield(seq,{j},'T', AllTrialSeq(j).T);
        seq = setfield(seq,{j},'y', AllTrialSeq(j).y); yDim = C;
    end
    
    
    figure(trial);
    
    
    params = [];
    
    % -------- PLDS Parameter Initialization
    
    params = PLDSInitialize(seq(trial),xDim,'NucNormMin',params);
    
    params.model.inferenceHandle = @PLDSLaplaceInference;   % comment out for using variational infernce
    
    params.opts.algorithmic.EMIterations.maxIter     = maxIter;	% setting max no of EM iterations
    params.opts.algorithmic.EMIterations.maxCPUTime  = 60;		% setting max CPU time 
    
    [params newseq varBound] = PopSpikeEM(params,seq(trial));
 
    
    
    %% assessment
    
    
    
    
    h1=subplot(211);
    imagesc(edges, [1:C],newseq.y);axis xy
    colormap(flipud(bone));
    ylabel('Cell','fontsize',16);
    title(num2str(trial),'fontsize',24);
    set(gca,'fontsize',16)
    
    set(gca,'Xticklabel',[]);
    
    
    
    range = [1: 100];
    base1 = mean(newseq.posterior.xsm(range));
    base2 = std(newseq.posterior.xsm(range));
    
    
    temporal_Z = (newseq.posterior.xsm - base1) / base2 ;
    
    
    subplot(212);
    hold on;
    tem1 = temporal_Z * sign(max(params.model.C)); 
    tem2 =  newseq.posterior.Vsm(1:xDim:end);
    
    
    ratio1 =   (newseq.posterior.xsm ) / (base2);
 
    hold on;
    fill([edges'; flipdim(edges',1)], [tem1'+sqrt(tem2)/base2; flipdim(tem1'-sqrt(tem2)/base2,1)], [6 6 6]/8,'EdgeColor',[6 6 6]/8);  
    plot(edges,tem1 ,'r-','linewidth',2);

    hold on;plot([edges(1) edges(end)],[1.65 1.65],'k--','linewidth',1);
    hold on;plot([edges(1) edges(end)],[-1.65 -1.65],'k--','linewidth',1);

    ylabel('Z-score','fontsize',16);
    set(gca,'fontsize',16)
    ylim([-5 5]);
    
  
 
end