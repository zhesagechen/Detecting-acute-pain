function [NOWparams newseq Qfun] = PLDS_EM(params,seq, binsize);



if nargin < 3; 
    binsize = 0.05; % 50 ms
end
 


Q0 = params.model.Q0;    
z0 = params.model.x0;    
 


Trials          = numel(seq); 
maxIter         = params.opts.algorithmic.EMIterations.maxIter;
maxCPUTime      = params.opts.algorithmic.EMIterations.maxCPUTime;
NOWparams       = params;

 

disp(['Starting EM'])
disp('----------------------------------------------------------------------------------------------------------------------------')


 
EMbeginTime = cputime;

sparse_opt = 1;

%%%%%%%%%%%  EM loop
for ii=1:maxIter
 
    NOWparams.state.EMiter = ii;
    infTimeBegin = cputime;

    %%%%%%% E-step: forward-backward smoother
    [smooth_state, stateCov_smooth, newseq, Qfun(ii)] = PLDS_filter_smoother(params, seq, z0,Q0, binsize) ;
       
   

    %%%%%%% M-step
    [NOWparams newseq] = PLDSMStep(NOWparams, newseq);
    
%     if sparse_opt == 1      
%         % update state driving noise   
%          tem =  (smooth_state(:,2:end)-smooth_state(:,1:end-1)) * (smooth_state(:,2:end)-smooth_state(:,1:end-1))';
%          Q = sqrtm(tem/(size(smooth_state,2)-1) + 0.00001*eye(size(smooth_state,1))); % L1 norm
%          NOWparams.model.Q = Q;
%     end
    
    infTimeEnd     = cputime;
    
    EMTimes(ii) = infTimeEnd-infTimeBegin;
    
    fprintf('\rIteration: %i     Elapsed EM time: %d      Qfun: %d',ii,EMTimes(ii), Qfun(ii))

    
    if (cputime-EMbeginTime)>maxCPUTime
       fprintf('\nReached maxCPUTime for EM, stopping')
       break
    end
end    